import cv2
import numpy as np
from tensorflow.keras.models import load_model
import os

# Load the trained model
model = load_model("C:/Users/megha/PycharmProjects/objectdetect/pythonProject/trainmodel-epoch-100.h5")

# Dictionary to map class indices to class labels
class_labels = {0: 'Maize', 1: 'others', 2: 'Weed'}  # Update with your class labels

# Function to preprocess the input image
def preprocess_image(img_path):
    img = cv2.imread(img_path)
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

    # Create a background subtractor
    bg_subtractor = cv2.createBackgroundSubtractorMOG2()

    # Apply background subtraction
    fg_mask = bg_subtractor.apply(gray)

    # Apply a binary threshold to get a binary mask
    _, binary_mask = cv2.threshold(fg_mask, 244, 255, cv2.THRESH_BINARY)

    # Invert the binary mask
    binary_mask_inv = cv2.bitwise_not(binary_mask)

    # Apply the binary mask to the original image
    result = cv2.bitwise_and(img, img, mask=binary_mask_inv)

    # Resize the image to the target size expected by the model
    result = cv2.resize(result, (150, 150))
    result = result.astype('float32') / 255
    result = np.expand_dims(result, axis=0)

    return result

# Create a folder to store captured images
if not os.path.exists('captured_images'):
    os.makedirs('captured_images')

# Function to perform object detection
def detect_objects(img_path):
    img_array = preprocess_image(img_path)
    prediction = model.predict(img_array)
    predicted_class = np.argmax(prediction)
    class_label = class_labels[predicted_class]
    return class_label

# Open camera
cap = cv2.VideoCapture(0)

while True:
    try:
        ret, frame = cap.read()

        if not ret:
            print("Failed to grab frame")
            break

        cv2.imshow('Object Detection', frame)

        # Save the frame as a temporary image file
        temp_img_path = "captured_images/temp.jpg"
        cv2.imwrite(temp_img_path, frame)

        # Perform object detection
        detected_object = detect_objects(temp_img_path)
        print("Detected Object:", detected_object)

        # Display the detected object name
        cv2.putText(frame, detected_object, (50, 50), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)

        cv2.imshow('Object Detection', frame)

        # Break the loop on pressing 'q' keyq
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break
    except Exception as e:
        print(f"An error occurred: {e}")
        break

# Release the camera and close all windows
cap.release()
cv2.destroyAllWindows()
